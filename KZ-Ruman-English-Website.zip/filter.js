const filters = [...document.querySelectorAll('.filters button')];
const posts = document.querySelectorAll('[data-topic]');
filters.forEach((button, index) => {
  button.addEventListener('click', () => {
    filters.forEach(filter => filter.setAttribute('aria-pressed', String(filter === button)));
    posts.forEach(post => { post.hidden = index !== 0 && post.dataset.topic !== button.textContent; });
  });
});
